create view sinisters_info as
  select `vialogik_dscic`.`sinisters`.`sinister_id`                                                         AS `sinister_id`,
         `vialogik_dscic`.`persons`.`person_name`                                                           AS `person_name`,
         `vialogik_dscic`.`persons`.`person_fname`                                                          AS `person_fname`,
         `vialogik_dscic`.`persons`.`person_lname`                                                          AS `person_lname`,
         `vialogik_dscic`.`clients`.`client_alias`                                                          AS `client_alias`,
         `vialogik_dscic`.`sinisters`.`sinister_ammount`                                                    AS `sinister_ammount`,
         `vialogik_dscic`.`vehicles`.`v_tag`                                                                AS `v_tag`,
         `vialogik_dscic`.`vehicles`.`v_id`                                                                 AS `v_id`,
         `vialogik_dscic`.`vehicles`.`v_provider_id`                                                        AS `v_provider_id`,
         `vialogik_dscic`.`vehicles`.`v_type`                                                               AS `v_type`,
         `vialogik_dscic`.`vehicles`.`v_capacity`                                                           AS `v_capacity`,
         `vialogik_dscic`.`vehicles`.`v_eco`                                                                AS `v_eco`,
         `vialogik_dscic`.`sites`.`site_alias`                                                              AS `site_alias`,
         `vialogik_dscic`.`sinisters`.`sinister_datetime`                                                   AS `sinister_datetime`,
         `vialogik_dscic`.`sinisters`.`sinister_trleave_datetime`                                           AS `sinister_trleave_datetime`,
         `vialogik_dscic`.`sinisters`.`sinister_kind`                                                       AS `sinister_kind`,
         `vialogik_dscic`.`sinisters`.`sinister_map_point`                                                  AS `sinister_map_point`,
         `vialogik_dscic`.`sinisters`.`sinister_moperandi`                                                  AS `sinister_moperandi`,
         `vialogik_dscic`.`sinisters`.`sinister_gps_system`                                                 AS `sinister_gps_system`,
         concat_ws(',', `vialogik_dscic`.`sinisters`.`sinister_call_report`,
                   `vialogik_dscic`.`sinisters`.`sinister_pre_report`,
                   `vialogik_dscic`.`sinisters`.`sinister_interv_report_id`,
                   `vialogik_dscic`.`sinisters`.`sinister_deep_interv`,
                   `vialogik_dscic`.`sinisters`.`sinister_bol_report`,
                   `vialogik_dscic`.`sinisters`.`sinister_check_list`,
                   `vialogik_dscic`.`sinisters`.`sinister_exit_pass`, `vialogik_dscic`.`sinisters`.`sinister_bills`,
                   `vialogik_dscic`.`sinisters`.`sinister_mp_act`)                                          AS `files`,
         (select `vialogik_dscic`.`providers`.`provider_alias`
          from `vialogik_dscic`.`providers`
          where (`vialogik_dscic`.`providers`.`provider_id` =
                 `vialogik_dscic`.`vehicles`.`v_provider_id`))                                              AS `provider_name`,
         `vialogik_dscic`.`sinisters`.`sinister_person_certcard`                                            AS `sinister_person_certcard`,
         `vialogik_dscic`.`sinisters`.`sinister_helper_certid`                                              AS `sinister_helper_certid`,
         `vialogik_dscic`.`sinisters`.`sinister_helper_pre_report`                                          AS `sinister_helper_pre_report`,
         `vialogik_dscic`.`sinisters`.`sinister_helper_deep_report`                                         AS `sinister_helper_deep_report`,
         `vialogik_dscic`.`sinisters`.`sinister_helper_person_id`                                           AS `sinister_helper_person_id`,
         `vialogik_dscic`.`sinisters`.`sinister_event_capture_timestamp`                                    AS `sinister_event_capture_timestamp`,
         `vialogik_dscic`.`sinisters`.`sinister_edit_status`                                                AS `sinister_edit_status`,
         `vialogik_dscic`.`sinisters`.`sinister_op_exp`                                                     AS `sinister_op_exp`,
         `vialogik_dscic`.`sinisters`.`sinister_ay_exp`                                                     AS `sinister_ay_exp`,
         `vialogik_dscic`.`sinisters`.`sinister_event_last_saved`                                           AS `sinister_event_last_saved`
  from ((((`vialogik_dscic`.`sinisters` left join `vialogik_dscic`.`persons` on ((`vialogik_dscic`.`persons`.`idpersons`
                                                                                  =
                                                                                  `vialogik_dscic`.`sinisters`.`sinister_person_id`))) left join `vialogik_dscic`.`clients` on ((
    `vialogik_dscic`.`clients`.`client_id` =
    `vialogik_dscic`.`sinisters`.`sinister_client_id`))) left join `vialogik_dscic`.`vehicles` on ((
    `vialogik_dscic`.`vehicles`.`v_id` =
    `vialogik_dscic`.`sinisters`.`sinister_v_id`))) left join `vialogik_dscic`.`sites` on ((
    `vialogik_dscic`.`sites`.`site_id` = `vialogik_dscic`.`sinisters`.`sinister_site_id`)));

